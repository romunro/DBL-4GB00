# Simple-INA226
A basic arduino library for communication with the TI INA226 chip

Works with the ESP8266

Please see the example for usage
